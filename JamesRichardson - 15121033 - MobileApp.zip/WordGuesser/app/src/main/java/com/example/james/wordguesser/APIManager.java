package com.example.james.wordguesser;

import android.util.JsonReader;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by James on 29/04/2018.
 */

public class APIManager {

    public String[] getWord() {
        String word = "";

        // Traversal of JSON random word follows the pattern: OBJECT -> STRING

        try {
            URL wordURL = new URL("http://api.wordnik.com:80/v4/words.json/randomWord?hasDictionaryDef=false&minCorpusCount=0&maxCorpusCount=-1&minDictionaryCount=1&maxDictionaryCount=-1&minLength=5&maxLength=-1&api_key=beb53b14a11fe1d4d968605e1350c6b2c719266a4353b88bc");

            // Create HTTPConnection and attempt to open connection
            HttpURLConnection myConnection = (HttpURLConnection) wordURL.openConnection();

            // Check response data
            if (myConnection.getResponseCode() == 200) {
                Log.d("CONNECTION MANAGER", "Successful Connection");

                // Extract data to inputstream
                InputStream responseData = myConnection.getInputStream();
                InputStreamReader responseDataReader = new InputStreamReader(responseData, "UTF-8");

                JsonReader jsonReader = new JsonReader(responseDataReader);

                jsonReader.beginObject();
                while (jsonReader.hasNext()){
                    String key = jsonReader.nextName();
                    if (key.equals("word")){

                        // Extract the word to a string
                        String value = jsonReader.nextString();

                        Log.d("FOUND WORD: ", value);
                        word = value;

                        break;
                    } else {
                        jsonReader.skipValue();
                    }
                }
                jsonReader.close();
                responseDataReader.close();

            } else {
                Log.d("CONNECTION MANAGER", "UNSUCCESSFUL CONNECTION REQUEST");
            }

            myConnection.disconnect();


        } catch (MalformedURLException mue) {
            Log.d("ERROR", "ERROR IN URL");
        } catch (IOException IOE){
            Log.d("ERROR", "Cannot Retrieve response code");
        }


        // Traversal of Examples API takes pattern: OBJECT -> ARRAY -> OBJECT -> STRING
        String exampleText = "";
        try {

            URL examplesURL = new URL("http://api.wordnik.com:80/v4/word.json/" + word + "/examples?includeDuplicates=false&useCanonical=false&skip=0&limit=5&api_key=beb53b14a11fe1d4d968605e1350c6b2c719266a4353b88bc");
            HttpURLConnection examplesConnection = (HttpURLConnection) examplesURL.openConnection();

            // Check response data
            if (examplesConnection.getResponseCode() == 200) {
                Log.d("CONNECTION MANAGER", "Successful Connection");

                // Extract data to inputstream
                InputStream responseData = examplesConnection.getInputStream();
                InputStreamReader responseDataReader = new InputStreamReader(responseData, "UTF-8");

                JsonReader examplesjsonReader = new JsonReader(responseDataReader);

                examplesjsonReader.beginObject();
                while (examplesjsonReader.hasNext()){
                    String key = examplesjsonReader.nextName();
                    if (key.equals("examples")){
                        examplesjsonReader.beginArray();

                        while(examplesjsonReader.hasNext()){
                            examplesjsonReader.beginObject();

                            while(examplesjsonReader.hasNext()) {
                                String key2 = examplesjsonReader.nextName();
                                if (key2.equals("text")) {

                                    exampleText = examplesjsonReader.nextString();
                                    Log.d("FOUND EXAMPLE", exampleText);
                                } else {
                                    examplesjsonReader.skipValue();
                                }
                            }
                        }
                        break;
                    } else {
                        examplesjsonReader.skipValue();
                    }
                }
                examplesConnection.disconnect();
                examplesjsonReader.close();
                responseDataReader.close();
            } else {
                Log.d("CONNECTION MANAGER", "UNSUCCESSFUL CONNECTION REQUEST");
            }

        } catch (MalformedURLException mue) {
            Log.d("ERROR", "ERROR IN URL");
        } catch (IOException IOE){
            Log.d("ERROR", "Cannot Retrieve response code");
        }

        // Traversal of Definition API takes pattern: ARRAY -> OBJECT -> STRING

        String defineText = "";
        try {

            URL defineURL = new URL("http://api.wordnik.com:80/v4/word.json/" + word + "/definitions?limit=200&includeRelated=true&useCanonical=false&includeTags=false&api_key=beb53b14a11fe1d4d968605e1350c6b2c719266a4353b88bc");
            HttpURLConnection defineConnection = (HttpURLConnection) defineURL.openConnection();

            // Check response data
            if (defineConnection.getResponseCode() == 200) {
                Log.d("CONNECTION MANAGER", "Successful Connection");

                // Extract data to inputstream
                InputStream responseData = defineConnection.getInputStream();
                InputStreamReader responseDataReader = new InputStreamReader(responseData, "UTF-8");

                JsonReader definejsonReader = new JsonReader(responseDataReader);

                definejsonReader.beginArray();
                while (definejsonReader.hasNext()){
                    definejsonReader.beginObject();
                    while (definejsonReader.hasNext()) {
                        String key = definejsonReader.nextName();
                        if (key.equals("text")) {
                            defineText = definejsonReader.nextString();
                            Log.d("FOUND DEFINITION", defineText);
                        } else {
                            definejsonReader.skipValue();
                        }
                    }
                }
                defineConnection.disconnect();
                definejsonReader.close();
                responseDataReader.close();
            } else {
                Log.d("CONNECTION MANAGER", "UNSUCCESSFUL CONNECTION REQUEST");
            }
        } catch (MalformedURLException mue) {
            Log.d("ERROR", "ERROR IN URL");
        } catch (IOException IOE){
            Log.d("ERROR", "Cannot Retrieve response code");
        }

        String[] values = {word, exampleText, defineText};
        return values;

    }


}


