package com.example.james.wordguesser;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);


        Button changeUser = (Button)findViewById(R.id.changeUserBtn);
        Button mainMenu = (Button)findViewById(R.id.mainMenuBtn);

        SharedPreferences userSettings = getSharedPreferences("userSettings", 0);
        final TextView statistics = (TextView)findViewById(R.id.statisticsTextView);

        int correctScore = userSettings.getInt("correctScore", 0);
        int incorrectScore = userSettings.getInt("incorrectScore", 0);
        int level = userSettings.getInt("level", 0);
        String loggedUser = userSettings.getString("username", "");


        statistics.setText("Logged user: " + loggedUser + "\nStatistics" +
        "\n\nCorrect Answers: " + correctScore + "\nIncorrect Answers: " + incorrectScore +
        "\nAccuracy Rate: " + (double)((double)correctScore/(double)incorrectScore) + "\nLevel: " + level);

        changeUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CreateAccount.class);
                startActivity(intent);
                finish();
            }
        });

        mainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainMenu.class);
                startActivity(intent);
                finish();
            }
        });

    }



}
