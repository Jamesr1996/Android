package com.example.james.wordguesser;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class AnswerScreen extends AppCompatActivity {

    private String answer = "";
    private String mark = "";
    CallbackManager callbackManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_answer_screen);
        // Establish SharedPrefs
        final SharedPreferences userSettings = getSharedPreferences("userSettings", 0);
        final SharedPreferences.Editor editor = userSettings.edit();

        // Get the data passed from the MainMenu class
        Intent intent = getIntent();

        // Check intent has content
        if (null != intent){
            answer = intent.getStringExtra("Answer");
            mark = intent.getStringExtra("Val");
        }

        // Initialize content variables
        TextView markView = (TextView)findViewById(R.id.markText);
        TextView answerText = (TextView)findViewById(R.id.answerBox);
        TextView scoreBox = (TextView)findViewById(R.id.scoreBox);
        Button nextQuestion = (Button)findViewById(R.id.nextWordBtn);
        LoginButton loginButton = (LoginButton)findViewById(R.id.login_button);


        // Load the users scores and change increment them
        int wrongscore = userSettings.getInt("incorrectScore", 0);
        int correctScore = userSettings.getInt("correctScore", 0);
        int xp = userSettings.getInt("xp", 0);

        if (mark.equals("Correct")) {
            markView.setText(mark + " + 5XP!");
            // Set text to green
            markView.setTextColor(Color.rgb(0,255,0));
            scoreBox.setText("Total: (" + correctScore + "+1)/" + wrongscore);
            editor.putInt("correctScore", correctScore+1);
            editor.putInt("xp", xp+5);


            editor.commit();

        // If the answer is "Incorrect" execute this
        } else {
            markView.setText(mark);
            markView.setTextColor(Color.rgb(255, 0,0));
            scoreBox.setText("Total: " + correctScore + "/(" + wrongscore + "+1)");
            editor.putInt("incorrectScore", wrongscore+1);
            editor.commit();

        }
        Log.d("ANSWER -------", answer);
        answerText.setText(answer);

        // Update Database here:
        // Get the Firebase instance
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        String username = userSettings.getString("username", "");
        DatabaseReference dbRef = database.getReference();

        // Check user already exists
        try {
            dbRef = database.getReference(username);
        } catch (Exception noReference){
            // Create new reference here
            dbRef.setValue(username);
            dbRef = dbRef.child(username);
        }

        // Create a hashmap of user details and set them to the new node
        Map<String, Object> userDetails = new HashMap<>();
        userDetails.put("Name", username);
        userDetails.put("CorrectScore", correctScore);
        userDetails.put("IncorrectScore", wrongscore);
        dbRef.setValue(userDetails);

        // Get the next question
        nextQuestion.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        // Retrieve data from API endpoint
                        // Get New Word From API
                        APIManager apMan = new APIManager();
                        String[] newWord = apMan.getWord();
                        Log.d("WORDMANAGER ------ ", "NEW WORD: " + newWord);
                        Intent intent = new Intent(getApplicationContext(), Question.class);
                        intent.putExtra("QuestionWord", newWord);
                        startActivity(intent);
                    }
                });
            }
        });


        callbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    // Navigate back to the main menu.
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(getApplicationContext(), MainMenu.class);
        startActivity(intent);
        finish();
    }
}
