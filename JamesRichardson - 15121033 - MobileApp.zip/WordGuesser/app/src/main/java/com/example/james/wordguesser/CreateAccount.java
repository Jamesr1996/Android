package com.example.james.wordguesser;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        Button submit = (Button)findViewById(R.id.createButton);
        final EditText password = (EditText)findViewById(R.id.createPassword);
        final EditText confirmPassword = (EditText)findViewById(R.id.confirmCreatePassword);
        final EditText username = (EditText)findViewById(R.id.createUsername);

        final SharedPreferences userSettings = getSharedPreferences("userSettings", 0);
        final SharedPreferences.Editor editor = userSettings.edit();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (password.getText().toString().equals(confirmPassword.getText().toString()) && password.length() > 0 && username.length()>0){
                    // Store details in new shared preferences
                    editor.putString("username", username.getText().toString());
                    Log.d("NEW USER:", username.getText().toString());
                    editor.putString("password", password.getText().toString());
                    editor.putInt("level", 0);
                    editor.commit();

                    Intent intent = new Intent(getApplicationContext(), MainMenu.class);
                    startActivity(intent);
                    finish();

                } else {
                    // Play Toast saying invalid credentials.
                    Toast.makeText(getApplicationContext(), "Invalid credentials", Toast.LENGTH_LONG).show();

                }
            }
        });


    }
}
