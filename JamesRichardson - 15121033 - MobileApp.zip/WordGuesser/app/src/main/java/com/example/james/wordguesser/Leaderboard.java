package com.example.james.wordguesser;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.text.DecimalFormat;


public class Leaderboard extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mRootRef = database.getReference();


        final TextView lbNames = (TextView)findViewById(R.id.lbNamesTV);
        final TextView lbCorrScores = (TextView)findViewById(R.id.lbCorrectTV);
        final TextView lbIncorrScores = (TextView)findViewById(R.id.lbIncorrTV);
        final TextView lbRate = (TextView)findViewById(R.id.lbRateTV);
        final TextView lbRank = (TextView)findViewById(R.id.lbRankTV);
        Button mainMenu = (Button)findViewById(R.id.lbMainMenu);

        mRootRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String names = "Username:";
                String corrScore = "Correct:";
                String incorrScore = "Incorrect:";
                String rank = "Rank:";
                String rates ="Ratio:";
                int count = 0;

                // Iterate through all Children of the root node
                for (DataSnapshot snap : dataSnapshot.getChildren()) {

                    names += "\n" + snap.child("Name").getValue(String.class);

                    int cScore = snap.child("CorrectScore").getValue(Integer.class);
                    corrScore += "\n" + cScore;

                    int iScore = snap.child("IncorrectScore").getValue(Integer.class);
                    incorrScore += "\n" + iScore;

                    count++;
                    rank += "\n" + count;

                    double ratio = ((double) (cScore) / (double) (iScore));
                    DecimalFormat df = new DecimalFormat("#.##");
                    rates += "\n" + "" + df.format(ratio);
                }

                lbNames.setText(names);
                lbIncorrScores.setText(incorrScore);
                lbCorrScores.setText(corrScore);
                lbRate.setText(rates);
                lbRank.setText(rank);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("Failed to read value:", databaseError.toException());
            }
        });

        mainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainMenu.class);
                startActivity(intent);
            }
        });


    }
}
