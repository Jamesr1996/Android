package com.example.james.wordguesser;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import java.lang.reflect.Type;

public class MainMenu extends AppCompatActivity {

    TextView Title;
    Typeface titlefont;
    private Button startButton;
    private Button leadBoardButton;
    private Button unlockButton;
    private Button accountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Set Title Font
        Title = (TextView) findViewById(R.id.menuTitle);
        titlefont = Typeface.createFromAsset(this.getAssets(), "fonts/Bauhaus 93.ttf");
        Title.setTypeface(titlefont);
        SharedPreferences userSettings = getSharedPreferences("userSettings", 0);


        // Uncomment to clear sharedPreferences.
//        SharedPreferences.Editor editor = userSettings.edit();
  //      editor.clear();
    //    editor.commit();


        String username = userSettings.getString("username", "");
        int level = userSettings.getInt("level",  0);

        Log.d("USERNAME FOUND -----: ", username);

        // Check if a user exists
        if (username == ""){
            // Display a user creation screen.
            Intent intent = new Intent(getApplicationContext(), CreateAccount.class);
            startActivity(intent);
        }

        TextView userTextView = (TextView)findViewById(R.id.usernameTextView);
        userTextView.setText(username + "\nLevel: " + level);

        // Set action for Start button
        startButton = (Button) findViewById(R.id.Start);
        startButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View V) {
                // Navigate to Question Page
                // Create background process to retrieve API data
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        // Retrieve data from API endpoint
                        // Get New Word From API
                        APIManager apMan = new APIManager();
                        String[] newWord = apMan.getWord();
                        Log.d("WORDMANAGER ------ ", "NEW WORD: " + newWord);
                        Intent intent = new Intent(getApplicationContext(), Question.class);
                        intent.putExtra("QuestionWord", newWord);
                        startActivity(intent);
                    }
                });

            }
        });

        // Set action for Leaderboard Button
        leadBoardButton = (Button) findViewById(R.id.leaderboardBtn);
        leadBoardButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View V){
                // Navigate to Leaderboard page
                startActivity(new Intent(getApplicationContext(), Leaderboard.class));
            }
        });

        // Set action for Unlocks Button
        unlockButton = (Button) findViewById(R.id.unlockBtn);
        unlockButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View V){
                // Navigate to Unlock Page
                startActivity(new Intent(getApplicationContext(), Unlocks.class));
            }
        });

        // Set action for Account Button
        accountButton = (Button) findViewById(R.id.accountBtn);
        accountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View V){
                // Navigate to Account page
                startActivity(new Intent(getApplicationContext(), Account.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
