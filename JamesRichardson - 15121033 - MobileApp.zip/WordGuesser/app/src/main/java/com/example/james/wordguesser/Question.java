package com.example.james.wordguesser;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.HttpURLConnection;

import javax.net.ssl.HttpsURLConnection;

public class Question extends AppCompatActivity {

    private String[] word;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        // Get the data passed from the MainMenu class
        Intent intent = getIntent();
        final SharedPreferences userSettings = getSharedPreferences("userSettings", 0);
        final SharedPreferences.Editor editor = userSettings.edit();

        TextView xpView = (TextView)findViewById(R.id.xpBar);
        TextView levelNo = (TextView)findViewById(R.id.levelView);
        int xp = userSettings.getInt("xp", 0);

        levelNo.setText("Level: " + userSettings.getInt("level", 0));
        xpView.setText(xp + "/" + userSettings.getInt("nextLevel", 5));

        // Check intent has content
        if (null != intent){
            word = intent.getStringArrayExtra("QuestionWord");
        }


        // Related Words Stored in slot 2
        TextView questionText = (TextView)findViewById(R.id.questionTitle);
        questionText.setText(word[2]);

        // Example sentence stored in Slot 1
        TextView exampleText = (TextView)findViewById(R.id.exampleText);

        // Replace all instances of the word in the example sentence with a blank space
        String hiddenText = word[1].replace(word[0], "______");
        exampleText.setText(hiddenText);

        // Answer stored in slot 0
        final TextView  defineText = (TextView)findViewById(R.id.defineText);
        Button hint = (Button)findViewById(R.id.hintBtn);
        hint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                defineText.setText(word[0]);
            }
        });

        Button submit = (Button)findViewById(R.id.submitAnswer);
        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                EditText answer = (EditText)findViewById(R.id.answerbox);

                Intent intent = new Intent(getApplicationContext(), AnswerScreen.class);
                intent.putExtra("Answer", word[0]);

                Log.d("USER ENTERED --", answer.getText().toString());
                if (answer.getText().toString().equals(word[0])) {
                    // Go to next Screen with "Correct"
                    intent.putExtra("Val", "Correct");

                } else {
                    // Go to next Screen with "INCORRECT"
                    intent.putExtra("Val", "Incorrect");
                }
                startActivity(intent);

            }
        });



        }

    public void onBackPressed(){
        Intent intent = new Intent(getApplicationContext(), MainMenu.class);
        startActivity(intent);
        finish();
    }

}
