package com.example.james.wordguesser;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Unlocks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unlocks);

        TextView unlockText = (TextView)findViewById(R.id.unlockTV);
        Button menu = (Button)findViewById(R.id.unlMenuBtn);

        unlockText.setText("Level 5: Additional Nouns" +
                "\nLevel 10: Related Images" +
                "\nLevel 20: Example Sentence" +
                "\nLevel 30: Second Attempt");

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainMenu.class);
                startActivity(intent);
            }
        });

    }

}
